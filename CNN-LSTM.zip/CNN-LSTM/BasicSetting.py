
base_setting = {
    'train_size': 0.8,
    'epochs': 100,
    'input_size': 60,
    'batch_size': 32,
    'pre_len': 1,
    'fileName': "",
    'model_name': 'rnn',
    'checkpoint_root_dir': './checkpoint-0507/dir',
    'true_epochs': 100,
    'data_root_dir': './data',
    'train_data_mode': 'pre',
    'train_set_cols': [1],
    'test_set_cols': [1],
    'continuous_output_sequence': False,
}

dir_predictor_setting = base_setting.copy()
dir_predictor_setting['checkpoint_dirs'] = []
