import os

from LSTM import models
import re
import math
from LSTM import preprocess, train, predict, evaluate

prediction_duration = 2 * 60 * 60

base_setting = {
    'train_size': 0.8,
    'epochs': 100,
    'input_size': 60,
    'batch_size': 32,
    'pre_len': 1,
    'fileName': "o2_i600s_w10_s1_fmean",
    'model_name': 'rnn',
    'checkpoint_root_dir': './checkpoint-0507/dir',
    'true_epochs': 100,
    'data_root_dir': './data',
    'train_data_mode': 'pre',
    'train_set_cols': [1],
    'test_set_cols': [1],
    'continuous_output_sequence': False,
}


def get_settings(setting):
    pre_len = get_pre_len(setting)
    settings = []
    for i in range(1, pre_len + 1):
        tmp_setting = setting.copy()
        tmp_setting['pre_len'] = i
        settings.append(tmp_setting)
        print(tmp_setting)
    return settings


def get_pre_len(setting):
    match = re.search(r'(?<=i)\d+(?=s)', setting['fileName'])
    timeInterval = int(match.group(0))  # 间隔时间，单位：秒
    pre_len = math.ceil(prediction_duration / timeInterval)
    return pre_len


def dir_train(settings):
    for setting in settings:
        preprocess(setting)
        train(setting)


def dir_predict(settings):
    pass


if __name__ == '__main__':
    files = ['o1_i900s_w10_s1_fmean']
    for file in os.listdir(base_setting['data_root_dir']):
        fileName = file.split('.')[0]
        if not fileName in files:
            print(f'{fileName} is complete')
            continue
        base_setting['fileName'] = fileName
        settings = get_settings(base_setting)
        for setting in settings:
            print(f'fileName: {fileName}, pre_len: {setting["pre_len"]}')
            preprocess(setting)
            train(setting)

