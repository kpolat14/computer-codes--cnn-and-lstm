import numpy as np

def lof_1d(data, k):
    distances = np.abs(np.subtract.outer(data, data))
    kdist = np.apply_along_axis(lambda x: np.sort(x)[k-1], 0, distances)
    lrd = 1 / (np.apply_along_axis(lambda x: np.sum(kdist[x != 0]), 0, distances) / (k * np.sum(kdist)))
    lof = np.apply_along_axis(lambda x: np.sum(lrd[x != 0]) / (lrd[x == 0] * np.sum(kdist[x != 0])), 0, distances)
    return lof

# 生成实验数据（正态分布和离群值）
np.random.seed(42)
X = np.concatenate([np.random.randn(100), np.array([10, 20, -10, -20])])
k = 5
lof = lof_1d(X, k)
print("LOF scores: ", lof)