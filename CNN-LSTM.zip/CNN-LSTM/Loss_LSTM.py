import tensorflow as tf



def custom_loss(y_true, y_pred):
    p = 1  # 预测值比真实值大时的权重
    q = 0.6  # 预测值比真实值小时的权重
    error = y_true - y_pred
    condition = tf.less_equal(error, 0)
    loss = tf.where(condition, q * tf.square(error), p * tf.square(error))
    return tf.reduce_mean(loss)


