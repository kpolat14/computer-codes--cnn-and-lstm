import os

from LSTM import preprocess, train, predict, evaluate
from logger import ResultLogger
import uuid
import numpy as np


setting = {
        'train_size': 0.8,
        'epochs': 50,
        'input_size': 60,
        'batch_size': 32,
        'pre_len': 1,
        'fileName': "section_flow_fill",
        'model_name': 'cnn-lstm',
        'checkpoint_root_dir': './checkpoint/out/loss',
        'loss': 'cost',
        'true_epochs': 50,
        'data_root_dir': './data',
        'train_data_mode': 'pre',
        'train_set_cols': [1],
        'test_set_cols': [1],
        'continuous_output_sequence': True,
        'shuffle_all': False,
    }

my_logger = ResultLogger()

if __name__ == '__main__':
    preprocess(setting)
    train(setting)
    pred, real = predict(setting)
    mse, rmse, mae, mape, r2 = evaluate(pred, real)
    print('mse:', mse)
    print('rmse:', rmse)
    print('mae:', mae)
    print('mape:', mape)
    print('r2:', r2)
    real_name = str(uuid.uuid4())
    real_data_path = f'./log_result/real_{real_name}.npy'
    pred_data_path = f'./log_result/pred_{str(uuid.uuid4())}.npy'
    real_data_path = os.path.abspath(real_data_path)
    pred_data_path = os.path.abspath(pred_data_path)
    np.save(real_data_path, real)
    np.save(pred_data_path, pred)
    pic = os.path.abspath(f'./log_pic/{real_name}.png')
    my_logger.log(setting['model_name'], setting['fileName'],real_data_path,
                  pred_data_path,1,
                  mse, rmse, mae, mape, r2,1,setting['loss'],additional_info=pic)


