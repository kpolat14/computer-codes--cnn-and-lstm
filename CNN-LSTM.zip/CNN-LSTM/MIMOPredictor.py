import os.path
# import logging
from LSTM import preprocess, predict, evaluate
from logger import ResultLogger
from utils import *

setting = {
        'train_size': 0.8,
        'epochs': 70,
        'input_size': 60,
        'batch_size': 32,
        'pre_len': 8,
        'fileName': "o1_i900s_w10_s1_fmean",
        'model_name': 'cnn-lstm',
        'checkpoint_root_dir': './checkpoint-0507/mimo',
        'true_epochs': 70,
        'data_root_dir': './data',
        'train_data_mode': 'pre',
        'train_set_cols': [1],
        'test_set_cols': [1],
        'continuous_output_sequence': True,
    }
model_name = '0507-lstm'
if __name__ == '__main__':
    logger = ResultLogger()
    preprocess(setting)
    pred, real = predict(setting)
    pred_file = logging_data(setting=setting, data=pred, data_type='mimo_pred')
    real_file = logging_data(setting=setting, data=real, data_type='mimo_real')
    for i in range(len(pred[0])):
        mse, rmse, mae, mape, r2 = evaluate(pred[:, i], real[:, i])
        logger.log(
            model_name=model_name,
            fileName=setting['fileName'],
            mse=mse,
            rmse=rmse,
            mae=mae,
            mape=mape,
            r2=r2,
            predict_data_path=os.path.abspath(pred_file),
            real_data_path=os.path.abspath(real_file),
            strategy='mimo',
            pre_len=setting['pre_len'],
            step_no=i+1,
        )
    mse, rmse, mae, mape, r2 = evaluate(pred, real)
    logger.log(
        model_name=model_name,
        fileName=setting['fileName'],
        mse=mse,
        rmse=rmse,
        mae=mae,
        mape=mape,
        r2=r2,
        predict_data_path=os.path.abspath(pred_file),
        real_data_path=os.path.abspath(real_file),
        strategy='mimo',
        pre_len=setting['pre_len'],
        step_no=0,
        additional_info='all'
    )

    print(f'mse: {mse} \n rmse: {rmse} \n mae: {mae} \n mape: {mape} \n r2: {r2}')
