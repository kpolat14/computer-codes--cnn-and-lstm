from LSTM import preprocess, train
from utils import *
from DirStrategy import get_pre_len

setting = {
        'train_size': 0.8,
        'epochs': 100,
        'input_size': 60,
        'batch_size': 16,
        'pre_len': 1,
        'fileName': "",
        'model_name': 'cnn-lstm',
        'checkpoint_root_dir': './checkpoint-0507/mimo',
        'true_epochs': 100,
        'data_root_dir': './data',
        'train_data_mode': 'pre',
        'train_set_cols': [1],
        'test_set_cols': [1],
        'continuous_output_sequence': True,
    }



if __name__ == '__main__':
    for file in ['o1_i900s_w10_s1_fmean.csv']:
        fileName = file.split('.')[0]
        setting['fileName'] = fileName
        setting['pre_len'] = get_pre_len(setting)
        logging_process(f'MIMOTrainer_start: {fileName}', setting)
        preprocess(setting)
        train(setting)
        logging_process(f'MIMOTrainer_end: {fileName}', setting)
