import math
import numpy as np
import matplotlib.pyplot as plt

cb = 66
cp = 0.67 * 60
v = 70

def hub_func(delt, a, b):
    # delt = y_pred - y_true
    if delt <= 0:
        return a * delt * delt
    elif delt > 0:
        return b * math.fabs(delt)
    else:
        return 0


def cost_loss(y_true, y_pred):
    y_add = math.ceil(y_true / v) * v
    y_sub = math.floor(y_true / v) * v
    n_pred = math.ceil(y_pred / v)
    n_true = math.ceil(y_true / v)
    if y_pred > y_add:
        return cb *  ((math.ceil(y_pred/v) - math.ceil(y_true/v)))
    elif y_pred < y_sub:
        if n_pred == n_true:
            return 0
        elif n_pred <= 0:
            return 0.01
        return (y_true - n_pred * v) * cp / n_pred
    return 0

if __name__ == '__main__':
    y_true = 1000
    x = [i for i in range(720, 1300)]
    y_preds =  [i for i in range(720, 1300)]
    y_p2 = [hub_func(i-1000,0.014,0.87) for i in range(720, 1300)]
    cost = [cost_loss(y_true, y_pred) for y_pred in y_preds]
    # plt.plot(x1, y1)
    plt.rcParams['font.family'] = 'Times New Roman'
    plt.rcParams['axes.unicode_minus'] = False
    plt.figure(dpi=200)
    plt.plot(x, y_p2, label='new loss', color='black')
    plt.plot(x, cost, label='cost func', color='gray', linestyle='--')
    plt.xticks(fontsize=20)
    plt.yticks(fontsize=20)
    plt.legend(fontsize=20, frameon=False, facecolor='none', loc='upper right', bbox_to_anchor=(1.041, 1.05))
    plt.grid(axis='both', alpha=.3)
    plt.savefig('./loss6.png')
    plt.show()
