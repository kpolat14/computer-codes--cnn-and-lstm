import os

from BasicSetting import *
from LSTM import predict, evaluate, preprocess
from DirStrategy import get_settings
import numpy as np
from utils import *
from logger import ResultLogger


def dir_predictor(setting):
    resultLogger = ResultLogger()

    settings = get_settings(setting)
    cur_dir = os.getcwd()


    tmp_setting = settings[0].copy()
    tmp_setting['pre_len'] = len(settings)
    tmp_setting['checkpoint_root_dir'] = ''
    tmp_setting['continuous_output_sequence'] = True
    preprocess(tmp_setting)
    base_x = tmp_setting['x_test']
    base_y = tmp_setting['y_test']

    for setting in settings:
        preprocess(setting)
        # setting['x_test'] = base_x
        # setting['y_test'] = base_y
        predicted, real = predict(setting)
        # predict_data_path = logging_data(predicted, setting, 'predict_data')
        # real_data_path = logging_data(real, setting, 'real_data')
        mse, rmse, mae, mape, r2 = evaluate(predicted, real)
        print(f'mse: {mse}\n rmse: {rmse}\n mae: {mae}\n mape: {mape}\n r2: {r2}')
        # resultLogger.log(model_name=setting['model_name'],
        #                  fileName=setting['fileName'],
        #                  real_data_path=os.path.abspath(real_data_path),
        #                  predict_data_path=os.path.abspath(predict_data_path),
        #                  mse=mse, rmse=rmse, mae=mae, mape=mape, r2=r2,
        #                  pre_len=len(settings),
        #                  step_no=setting['pre_len'],strategy='direct')

    #     if predict_result is None:
    #         predict_result = predicted
    #     else:
    #         predict_result = np.concatenate((predict_result, predicted), axis=1)
    #
    # return predict_result, base_y


if __name__ == '__main__':
    dir_predictor_setting['fileName'] = 'o1_i900s_w10_s1_fmean'
    dir_predictor(dir_predictor_setting)
    # mse, rmse, mae, mape, r2 = evaluate(predict_result, real)
    # print(f'mse: {mse}\n rmse: {rmse}\n mae: {mae}\n mape: {mape}\n r2: {r2}')
