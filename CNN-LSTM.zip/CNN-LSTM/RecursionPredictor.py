from LSTM import preprocess, predict, evaluate
from utils import *
from DirStrategy import get_pre_len
import copy
from logger import ResultLogger

model_name = 'cnn-lstm'
logger = ResultLogger()
setting = {
    'train_size': 0.8,
    'epochs': 100,
    'input_size': 60,
    'batch_size': 32,
    'pre_len': 1,
    'fileName': "",
    'model_name': 'lstm',
    'checkpoint_root_dir': './checkpoint-cnn/recursion',
    'true_epochs': 100,
    'data_root_dir': './data',
    'train_data_mode': 'pre',
    'train_set_cols': [1],
    'test_set_cols': [1],
    'continuous_output_sequence': True,
}





def recursion_predict(setting):
    pre_len = get_pre_len(setting)
    y_test = setting['y_test']
    x_test = setting['x_test']
    sc = setting['sc']
    x = x_test
    model = setting['model']
    for i in range(pre_len):
        pred = model.predict(x)
        y = copy.deepcopy(pred)
        pred = sc.inverse_transform(pred)
        pred_file = logging_data(pred, setting, f'recursion_predict_pred_{i}')
        real = y_test[:, i]
        real = real.reshape(-1, 1)
        real = sc.inverse_transform(real)
        real_file = logging_data(real, setting, f'recursion_predict_real_{i}')
        mse, rmse, mae, mape, r2 = evaluate(pred, real)
        print(f'recursion_predict: {i} mse: {mse} rmse: {rmse} mae: {mae} mape: {mape} r2: {r2}')
        logger.log(
            model_name=model_name,
            fileName=setting['fileName'],
            mse=mse,
            rmse=rmse,
            mae=mae,
            mape=mape,
            r2=r2,
            predict_data_path=os.path.abspath(pred_file),
            real_data_path=os.path.abspath(real_file),
            strategy='recursion',
            pre_len=setting['pre_len'],
            step_no=i + 1,
        )
        x = x.reshape(x.shape[0], x.shape[1])
        x = np.concatenate((x, y), axis=1)
        x = x[:, 1:]
        x = x.reshape(x.shape[0], x.shape[1], 1)
        print(f'recursion_predict: {i}')



if __name__ == '__main__':
    setting['fileName'] = 'o1_i900s_w10_s1_fmean'
    fileName = setting['fileName']
    logging_process(f'recursion_predict_start: {fileName}', setting)
    setting['pre_len'] = get_pre_len(setting)
    preprocess(setting)
    x_test = copy.deepcopy(setting['x_test'])
    y_test = copy.deepcopy(setting['y_test'])
    setting['pre_len'] = 1
    preprocess(setting)
    setting['x_test'] = x_test
    setting['y_test'] = y_test
    recursion_predict(setting)


