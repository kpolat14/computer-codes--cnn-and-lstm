from LSTM import preprocess, train, predict, evaluate

setting = {
    'train_size': 0.8,
    'epochs': 1,
    'input_size': 60,
    'pre_len': 1,
    'batch_size': 32,
    'fileName': "o1_i900s_w10_s1_fmean",
    'model_name': 'lstm',
    'checkpoint_root_dir': './checkpoint-0507/recursion',
    'true_epochs': 100,
    'data_root_dir': './data',
    'train_data_mode': 'pre',
    'train_set_cols': [1],
    'test_set_cols': [1],
    'continuous_output_sequence': True,
}

if __name__ == '__main__':
    preprocess(setting)
    train(setting)
