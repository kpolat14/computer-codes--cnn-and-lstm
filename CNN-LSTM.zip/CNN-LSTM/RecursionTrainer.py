from LSTM import preprocess, train, predict, evaluate
import os
from utils import *

setting = {
        'train_size': 0.8,
        'epochs': 100,
        'input_size': 60,
        'batch_size': 32,
        'pre_len': 1,
        'fileName': "o1_i1800s_w10_s1_fmean",
        'model_name': 'lstm',
        'checkpoint_root_dir': './checkpoint/recursion',
        'true_epochs': 100,
        'data_root_dir': './data',
        'train_data_mode': 'pre',
        'train_set_cols': [1],
        'test_set_cols': [1],
        'continuous_output_sequence': True,
    }


if __name__ == '__main__':
    for file in os.listdir(setting['data_root_dir']):
        fileName = file.split('.')[0]
        setting['fileName'] = fileName
        logging_process(f'recursion Trainer_start: {fileName}', setting)
        preprocess(setting)
        train(setting)
        logging_process(f'recursion Trainer_end: {fileName}', setting)