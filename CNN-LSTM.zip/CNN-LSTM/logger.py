import logging
import pymysql
from sqlalchemy import Column, Integer, String, Float, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import datetime

class Logger:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.logger = None
        return cls._instance

    def init_logger(self, level=logging.DEBUG, log_file_path=None):
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(level)

        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')

        if log_file_path:
            file_handler = logging.FileHandler(log_file_path)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)

        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

    def debug(self, msg):
        self.logger.debug(msg)

    def info(self, msg):
        self.logger.info(msg)

    def warning(self, msg):
        self.logger.warning(msg)

    def error(self, msg):
        self.logger.error(msg)

    def critical(self, msg):
        self.logger.critical(msg)


class RelationalDataLogger():
    def __init__(self, host, port, user, password, database, charset='utf8mb4',
                 cursor_class=pymysql.cursors.DictCursor):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.charset = charset
        self.cursor_class = cursor_class
        self.conn = None
        self.cursor = None

    def connect(self):
        self.conn = pymysql.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            db=self.database,
            charset=self.charset,
            cursorclass=self.cursor_class
        )
        self.cursor = self.conn.cursor()

    def execute(self, sql, args=None):
        self.cursor.execute(sql, args)
        return self.cursor.fetchall()

    def commit(self):
        self.conn.commit()

    def close(self):
        self.cursor.close()
        self.conn.close()




Base = declarative_base()

class Table(Base):
    __tablename__ = 'predict_result'

    id = Column(Integer, primary_key=True, autoincrement=True)
    time = Column(DateTime, default=datetime.datetime.now)
    model_name = Column(String(255), nullable=False)
    fileName = Column(String(255), nullable=False)
    real_data_path = Column(String(255), nullable=False)
    predict_data_path = Column(String(255), nullable=False)
    step_no = Column(Integer, nullable=False)
    mse = Column(Float, nullable=True)
    rmse = Column(Float, nullable=True)
    mae = Column(Float, nullable=True)
    mape = Column(Float, nullable=True)
    r2 = Column(Float, nullable=True)
    pre_len = Column(Integer, nullable=False)
    additional_info = Column(String(255), nullable=True)
    strategy = Column(String(255), nullable=False)

class ResultLogger:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            engine = create_engine('mysql+pymysql://root:111@localhost:3306/logging?charset=utf8mb4')
            DBSession = sessionmaker()
            cls._instance.logger = DBSession()

        return cls._instance

    def log(self, model_name, fileName, real_data_path, predict_data_path,
            step_no, mse, rmse, mae, mape, r2, pre_len, strategy,
            additional_info=None):
        result = Table(
            model_name=model_name,
            fileName=fileName,
            real_data_path=real_data_path,
            predict_data_path=predict_data_path,
            step_no=step_no,
            mse=mse,
            rmse=rmse,
            mae=mae,
            mape=mape,
            r2=r2,
            pre_len=pre_len,
            strategy=strategy,
            additional_info=additional_info
        )
        self.logger.add(result)
        self.logger.commit()

