import os
import numpy as np

A = np.ones((200, 60, 1))
B = np.ones((200, 1))

# 使用 reshape 函数将 A 重塑为 (200, 60) 的形状
A = A.reshape((200, 60))

# 输出结果的 shape
print(A.shape)  # (200, 60)

a = np.concatenate((A, B), axis=1)
a = a[:, 1:]
a = a.reshape((200, 60, 1))
print(a.shape)