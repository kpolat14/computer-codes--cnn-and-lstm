from datetime import datetime
import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Dropout, Dense, LSTM, SimpleRNN, GRU, Conv1D
import matplotlib.pyplot as plt
import os
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, mean_absolute_percentage_error, r2_score
import math

figNum = 1
train_size = 0.8
epochs = 100
true_epochs = 1
pre_len = 6
input_size = 120
fileName = "o2_i600s_w10_s1_fmean"
model_name = 'cnn-lstm'
trans_set = False

checkpoint_save_path = f'./long_predict/{fileName}/epochs{epochs}_i{input_size}_nn{pre_len}_{model_name}/LSTM_pf.ckpt'

LSTM_Layer1 = LSTM(units=80, return_sequences=True, input_shape=(input_size, 1))
LSTM_Layer2 = LSTM(units=100)

model = tf.keras.Sequential([
    # Conv1D(filters=32, kernel_size=3, padding='same', activation='relu', input_shape=(input_size, 1)),
    LSTM_Layer1,
    Dropout(0.2),
    LSTM_Layer2,
    Dropout(0.2),
    Dense(pre_len)
])
#
model.compile(optimizer=tf.keras.optimizers.Adam(0.001),
              loss='mean_squared_error')  # 损失函数用均方误差
if os.path.exists(checkpoint_save_path + '.index'):
    print('-------------load the model-----------------')
    model.load_weights(checkpoint_save_path)

cp_callback = tf.keras.callbacks.ModelCheckpoint(filepath=checkpoint_save_path,
                                                 save_weights_only=True,
                                                 save_best_only=True,
                                                 monitor='val_loss')


def get_data(training_set, test_set):
    # 归一化
    sc = MinMaxScaler(feature_range=(0, 1))
    training_set_scaled = sc.fit_transform(training_set)
    test_set = sc.transform(test_set)
    #
    x_train = []
    y_train = []

    x_test = []
    y_test = []

    # 测试集：csv表格中前2426-300=2126天数据
    for i in range(input_size, len(training_set_scaled) - pre_len):
        x_train.append(training_set_scaled[i - input_size:i, 0])
        y_train.append(training_set_scaled[i:i + pre_len, 0])
    # 对训练集进行打乱
    np.random.seed(7)
    np.random.shuffle(x_train)
    np.random.seed(7)
    np.random.shuffle(y_train)
    tf.random.set_seed(7)
    # 将训练集由list格式变为array格式
    x_train, y_train = np.array(x_train), np.array(y_train)

    x_train = np.reshape(x_train, (x_train.shape[0], input_size, 1))
    # 测试集：csv表格中后300天数据
    for i in range(input_size, len(test_set) - pre_len):
        x_test.append(test_set[i - input_size:i, 0])
        y_test.append(test_set[i:i + pre_len, 0])
    # 测试集变array并reshape为符合RNN输入要求：[送入样本数， 循环核时间展开步数， 每个时间步输入特征个数]
    x_test, y_test = np.array(x_test), np.array(y_test)
    x_test = np.reshape(x_test, (x_test.shape[0], input_size, 1))
    return x_train, y_train, x_test, y_test, sc, test_set


def train(x_train, y_train, x_test, y_test):
    print(type(x_train), x_train.shape)
    print(type(y_train), y_train.shape)
    print(type(x_test), x_test.shape)
    print(type(y_test), y_test.shape)

    history = model.fit(x_train, y_train, batch_size=16, epochs=true_epochs, validation_data=(x_test, y_test),
                        validation_freq=1,
                        callbacks=[cp_callback])

    model.summary()

    # if not os.path.exists(weight_save_file):
    #     os.mkdir(weight_save_file)

    # file = open(weight_save_file + '/weights.txt', 'w')  # 参数提取
    # for v in model.trainable_variables:
    #     file.write(str(v.name) + '\n')
    #     file.write(str(v.shape) + '\n')
    #     file.write(str(v.numpy()) + '\n')
    # file.close()

    loss = history.history['loss']
    val_loss = history.history['val_loss']



    return loss, val_loss


def mape_m(actual, pred):
    return np.mean(np.abs((actual - pred) / actual)) * 100


def predict(sc, model, x_test, y_test):
    predicted = model.predict(x_test)
    predicted = sc.inverse_transform(predicted)
    real = sc.inverse_transform(y_test)

    return predicted, real


def evaluate(predicted, real):
    mse = mean_squared_error(predicted, real)
    rmse = math.sqrt(mean_squared_error(predicted, real))
    mae = mean_absolute_error(predicted, real)

    mape = mean_absolute_percentage_error(predicted, real)
    r2 = r2_score(predicted, real)
    return mse, rmse, mae, mape, r2


def core(fileName):
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
    data_set = pd.read_csv('./data/' + fileName + ".csv")
    print(int(len(data_set) * train_size))
    training_set = data_set.iloc[0:int(len(data_set) * train_size), 1:2].values
    test_set = data_set.iloc[int(len(data_set) * train_size):, 1:2].values
    if trans_set:
        training_set = data_set.iloc[int((1 - train_size) * len(data_set)):, 1:2].values
        test_set = data_set.iloc[:int((1 - train_size) * len(data_set)), 1:2].values
    # pass
    x_train, y_train, x_test, y_test, sc, test_set = get_data(training_set, test_set)
    print(x_test)
    loss, val_loss = train(x_train, y_train, x_test, y_test)


if __name__ == '__main__':
    fileName = "o2_i600s_w10_s1_fmean"
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
    data_set = pd.read_csv('./data/' + fileName + ".csv")
    training_set = data_set.iloc[0:int(len(data_set) * train_size), 1:2].values
    test_set = data_set.iloc[int(len(data_set) * train_size):, 1:2].values
    # pass
    x_train, y_train, x_test, y_test, sc, test_set = get_data(training_set, test_set)
    loss, val_loss = train(x_train, y_train, x_test, y_test)

    # plt.plot(loss, label='Training Loss')
    # plt.plot(val_loss, label='Validation Loss')
    # plt.title('Training and Validation Loss')
    # plt.legend()
    # plt.show()
    log_dir = f"./result/log/mimo/{fileName}/epochs{epochs}_i{input_size}_nn{pre_len}_{model_name}/{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    pre, real = predict(sc, model, x_test, y_test)
    np.save(log_dir + "/pre.npy", pre)
    np.save(log_dir + "/real.npy", real)
    mse, rmse, mae, mape, r2 = evaluate(pre[:100], real[:100])
    prop = "均方误差mse: {0:{1}} \n".format(mse, ".6f") + \
           "均方根误差rmse: {0:{1}} \n".format(rmse, ".6f") + \
           '平均绝对误差mae: {0:{1}} \n'.format(mae, ".6f") + \
           '平均绝对百分比误差mape: {0:{1}} \n'.format(mape, ".6f") + \
           'R2: {0:{1}} \n'.format(r2, ".6f")
    print(prop)
    print(pre[10])
    print(real[10])
