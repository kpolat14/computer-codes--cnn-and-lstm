import pandas as pd
import numpy as np
import random

data = pd.read_csv('data.csv')
signal = data['num'].values
seq = np.array(signal)
c = (len(seq)//(96))
# print(c)
seq = seq[:(len(seq)//(96)) * (96)]



seq = seq.reshape((-1,(96)))
e = 0
t = 0
for i in range(seq.shape[1]):
    col = seq[:,i]
    # print(len(col))
    e_idx = []
    for j in range(2):
        idx = random.randint(0,c-1)
        e_idx.append(idx)
        col[idx] =  random.randint(0, 100 * int(col[idx]))

    outls = z_score(col)

    if outls is not None:
        for j in outls[0]:
            t += len(outls[0])
            if j in e_idx:
                e += 1


    # seq[:,i] = col

seq = seq.reshape((-1,))

print(e)
print(e/(2*96))
print(t)
# print(len(index))
# df = pd.DataFrame(seq)
# df.to_csv('./data.csv')


