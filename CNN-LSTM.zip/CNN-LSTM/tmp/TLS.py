import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from statsmodels.tsa.seasonal import seasonal_decompose

# 读入数据
df = pd.read_csv('o1_i900s_w1_s1_fmean.csv', index_col='dateTime',parse_dates=True)

def stl(data, freq):
    decomposition = seasonal_decompose(data, model='additive', period=freq)
    return data, decomposition.trend,decomposition.seasonal,decomposition.resid

def draw(df,trend,seasonal,resid):
    # 绘图
    fig, axs = plt.subplots(4, figsize=(10, 8))

    axs[0].set_title('y(t)')
    axs[0].plot(df)

    axs[1].set_title('T(t)')
    axs[1].plot(trend)

    axs[2].set_title('S(t)')
    axs[2].scatter(seasonal.index, seasonal, s=1)

    axs[3].set_title('E(t)')
    axs[3].plot(resid)

    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    data, trend, seasonal, resid = stl(df[8000:9500],15)
    draw(data, trend, seasonal, resid)
    for i in range(0):
        resid = resid.to_frame()
        resid['resid'] = resid['resid'].fillna(0)
        data, trend, seasonal, resid = stl(resid, 15)
        draw(data[:1000], trend[:1000], seasonal[:1000], resid[:1000] )