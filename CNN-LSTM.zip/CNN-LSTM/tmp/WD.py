import pywt
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_csv('./data.csv')
signal = data['num'].values


# 进行小波分解
w = pywt.Wavelet('haar')
coeffs = pywt.wavedec(signal, w, level=2)

# 绘制小波分量
plt.subplot(411)
plt.plot(signal[:500])
plt.title('Original Signal')

plt.subplot(412)
plt.plot(coeffs[0][:500])
plt.title('Approximation Coefficients')

plt.subplot(413)
plt.plot(coeffs[1][:500])
plt.title('Level 1 Detail Coefficients')

plt.subplot(414)
plt.plot(coeffs[2][:500])
plt.title('Level 2 Detail Coefficients')

plt.tight_layout()
plt.show()
