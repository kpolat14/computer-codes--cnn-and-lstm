import numpy as np

# 生成实验数据
np.random.seed(42)
X = np.random.randn(20)


def z_score(x):
    mean = np.mean(x)
    std = np.std(x)

    threshold = 1
    if std == 0:
        return None
    z = (x - mean) / std
    outliers = np.where(np.abs(z) > threshold)

    # print(outliers)
    # x[outliers] = mean
    return outliers

# if __name__ == '__main__':
#     x= z_score(X)
#     print(X)
