import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('./data.csv')
plt.plot(data[:1000])
plt.show()
