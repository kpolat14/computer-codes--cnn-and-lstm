import numpy as np
from ZScore import z_score

x = np.array([1,2,3,4,5,6,7,8,9,10])
y = np.array([2,4,6,8,10,12,14,16,18,20])

print(np.corrcoef(x,y))
print(np.std(x))
print(np.std(y))
print(z_score(x))
print(z_score(y))