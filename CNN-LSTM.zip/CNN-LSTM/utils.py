import os

import numpy as np
import logging
import json
import time
import matplotlib.pyplot as plt


base_setting = {
    'train_size': 0.8,
    'epochs': 100,
    'input_size': 60,
    'batch_size': 32,
    'pre_len': 1,
    'fileName': "",
    'model_name': 'lstm',
    'checkpoint_root_dir': './checkpoint/dir',
    'true_epochs': 100,
    'data_root_dir': './data',
    'train_data_mode': 'pre',
    'train_set_cols': [1],
    'test_set_cols': [1],
    'continuous_output_sequence': False,
}

logging.format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'


def logging_template(setting, default_log_data_dir, log_data_name, additional_info=None):
    update_num = 0
    my_setting = base_setting.copy()
    for key in setting:
        if key in my_setting:
            my_setting[key] = setting[key]
    setting = my_setting

    if 'log_data_dir' in setting:
        default_log_data_dir = setting['log_data_dir']
    if os.path.exists(default_log_data_dir) is False:
        os.makedirs(default_log_data_dir)

    # log_data_name =
    if 'log_data_name' in setting:
        log_data_name = setting['log_data_name']
    update_log_file = os.path.join(default_log_data_dir, f"{log_data_name}update.json")
    update_log = {}
    logs = []
    if os.path.exists(update_log_file):
        update_log = json.load(open(update_log_file, 'r'))
    if 'update_num' in update_log:
        update_num = update_log['update_num'] + 1
    if 'logs' in update_log:
        logs = update_log['logs']

    time_key = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    entry = {}
    entry[time_key] = {}
    entry[time_key]['setting'] = setting
    entry[time_key]['additional_info'] = additional_info
    logs.append(entry)

    update_log['update_num'] = update_num
    update_log['logs'] = logs
    return update_log, update_log_file


def logging_data(data, setting, data_type, additional_info=None):
    update_num = 0
    default_log_data_dir = './log_data'

    my_setting = base_setting.copy()
    for key in setting:
        if key in my_setting:
            my_setting[key] = setting[key]
    setting = my_setting
    if 'log_data_dir' in setting:
        default_log_data_dir = setting['log_data_dir']
    if os.path.exists(default_log_data_dir) is False:
        os.makedirs(default_log_data_dir)

    log_data_name = f"{data_type}_" \
                    f"{setting['fileName']}_" \
                    f"m{setting['model_name']}_" \
                    f"tdm{setting['train_data_mode']}_" \
                    f"pl{setting['pre_len']}_" \
                    f"cs{str(setting['continuous_output_sequence'])}_"
    if 'log_data_name' in setting:
        log_data_name = setting['log_data_name']

    if os.path.exists(os.path.join(default_log_data_dir, 'update_logs')) is False:
        os.makedirs(os.path.join(default_log_data_dir, 'update_logs'))

    update_log_file = os.path.join(default_log_data_dir,'update_logs', f"{log_data_name}update.json")
    update_log = {}
    logs = []
    if os.path.exists(update_log_file):
        update_log = json.load(open(update_log_file, 'r'))
    if 'update_num' in update_log:
        update_num = update_log['update_num'] + 1
    if 'logs' in update_log:
        logs = update_log['logs']
    log_data_file = os.path.join(default_log_data_dir, f"{log_data_name}_u{update_num}.npy")

    time_key = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    entry = {}
    entry[time_key] = {}
    entry[time_key]['file'] = str(log_data_file)
    entry[time_key]['setting'] = setting
    entry[time_key]['additional_info'] = additional_info
    logs.append(entry)

    update_log['update_num'] = update_num
    update_log['logs'] = logs
    json.dump(update_log, open(update_log_file, 'w'))

    np.save(log_data_file, data)
    return log_data_file


def logging_result(result, setting, additional_name=None, additional_info=None):
    log_data_name = f"{setting['fileName']}_" \
                    f"m{setting['model_name']}_" \
                    f"tdm{setting['train_data_mode']}_" \
                    f"pl{setting['pre_len']}_" \
                    f"cs{str(setting['continuous_output_sequence'])}_"
    log_data_name = 'result_' + log_data_name
    logger, file = logging_template(setting,
                                    './log_result',
                                    log_data_name,
                                    additional_info=additional_info)
    logger['logs'][len(logger['logs']) - 1]['result'] = result
    json.dump(logger, open(file, 'w'))


def logging_process(process_name, setting, additional_name=None, additional_info=None):
    print(f"logging process: {process_name}")
    log_data_name = f"process_{setting['fileName']}_" \
                    f"m{setting['model_name']}_" \
                    f"tdm{setting['train_data_mode']}_" \
                    f"pl{setting['pre_len']}_" \
                    f"cs{str(setting['continuous_output_sequence'])}_"
    logger, file = logging_template(setting,
                                    './log_process',
                                    log_data_name,
                                    additional_info=additional_info)
    logger['process'] = process_name
    json.dump(logger, open(file, 'w'))


# def draw_predict(predict, real, dir):
#     plt.rcParams['font.family'] = 'Times New Roman'
#     plt.rcParams['axes.unicode_minus'] = False
#
#     plt.figure(dpi=200)
#     plt.plot(real, label='real', color='gray', linestyle='--')
#     plt.plot(predict, label='pred', color='black')
#     plt.legend(fontsize=20,bbox_to_anchor=(0, 0.95, 1, 0.2), loc='lower center', ncol=2, frameon=False, facecolor='none')
#     # plt.legend(fontsize=20,frameon=False,facecolor='none' ,loc='upper right', bbox_to_anchor=(1.041, 1.05))
#     plt.xticks(fontsize=20)
#     plt.yticks(fontsize=20)
#     plt.grid(axis='both', alpha=.3)
#     plt.savefig(dir, dpi=200, bbox_inches='tight')
#     plt.show()